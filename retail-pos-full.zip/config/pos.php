<?php

return ['currency' => env('POS_CURRENCY', 'BDT'), 'symbol' => env('POS_CURRENCY_SYMBOL', '৳')];
