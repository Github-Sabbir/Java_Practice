<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('supplier_payments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('supplier_id')->constrained()->restrictOnDelete();
            $t->foreignId('purchase_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('user_id')->constrained()->restrictOnDelete();
            $t->decimal('amount', 15, 2);
            $t->string('payment_method')->default('cash');
            $t->text('note')->nullable();
            $t->timestamp('paid_at');
            $t->timestamps();
        });
        Schema::create('customer_payments', function (Blueprint $t) {
            $t->id();
            $t->foreignId('customer_id')->constrained()->restrictOnDelete();
            $t->foreignId('sale_id')->nullable()->constrained()->nullOnDelete();
            $t->foreignId('user_id')->constrained()->restrictOnDelete();
            $t->decimal('amount', 15, 2);
            $t->string('payment_method')->default('cash');
            $t->text('note')->nullable();
            $t->timestamp('paid_at');
            $t->timestamps();
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('customer_payments');
        Schema::dropIfExists('supplier_payments');
    }
};
