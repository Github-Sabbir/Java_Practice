<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class Purchase extends Model
{
    protected $fillable = ['reference_no', 'supplier_id', 'user_id', 'subtotal', 'discount', 'tax', 'total', 'paid', 'due', 'status'];
    protected $casts = ['subtotal' => 'decimal:2', 'discount' => 'decimal:2', 'tax' => 'decimal:2', 'total' => 'decimal:2', 'paid' => 'decimal:2', 'due' => 'decimal:2'];
    public function items()
    {
        return $this->hasMany(PurchaseItem::class);
    }
    public function supplier()
    {
        return $this->belongsTo(Supplier::class);
    }
}
