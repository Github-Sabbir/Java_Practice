<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
class SaleItem extends Model
{
    protected $fillable = ['sale_id', 'product_id', 'quantity', 'unit_price', 'cost_price', 'discount', 'tax', 'line_total'];
    protected $casts = ['quantity' => 'decimal:3', 'unit_price' => 'decimal:2', 'cost_price' => 'decimal:2', 'discount' => 'decimal:2', 'tax' => 'decimal:2', 'line_total' => 'decimal:2'];
    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}
