<?php $__env->startSection('content'); ?>
<div class="page-head"><div><h1>Purchase <?php echo e($purchase->reference_no); ?></h1><p>Purchase details and stock received.</p></div><a class="secondary" href="<?php echo e(route('purchases.index')); ?>">Back</a></div>
<div class="glass table-wrap"><p><b>Supplier:</b> <?php echo e($purchase->supplier?->name ?? 'Walk-in supplier'); ?></p><p><b>Total:</b> ৳<?php echo e(number_format($purchase->total,2)); ?> &nbsp; <b>Paid:</b> ৳<?php echo e(number_format($purchase->paid,2)); ?> &nbsp; <b>Due:</b> ৳<?php echo e(number_format($purchase->due,2)); ?></p>
<table><thead><tr><th>Product</th><th>Qty</th><th>Unit Cost</th><th>Total</th></tr></thead><tbody>
<?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($item->product?->name); ?></td><td><?php echo e($item->quantity); ?></td><td>৳<?php echo e(number_format($item->unit_cost,2)); ?></td><td>৳<?php echo e(number_format($item->line_total,2)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody></table></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/purchases/show.blade.php ENDPATH**/ ?>