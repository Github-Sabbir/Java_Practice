<?php $__env->startSection('content'); ?>
<div class="page-head"><div><div class="eyebrow">INVENTORY HISTORY</div><h1>Purchases</h1><p class="muted">Received stock, supplier balances and purchase payments.</p></div><a class="primary" href="<?php echo e(route('purchases.create')); ?>">＋ New Purchase</a></div>
<div class="glass table-wrap"><table><thead><tr><th>Reference</th><th>Supplier</th><th>Total</th><th>Paid</th><th>Due</th><th>Actions</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
<td><span class="purchase-ref"><?php echo e($x->reference_no); ?></span></td>
<td><?php echo e($x->supplier?->name ?? 'Cash purchase'); ?></td>
<td>৳<?php echo e(number_format($x->total,2)); ?></td>
<td>৳<?php echo e(number_format($x->paid,2)); ?></td>
<td><strong class="<?php echo e((float)$x->due>0?'low':''); ?>">৳<?php echo e(number_format($x->due,2)); ?></strong></td>
<td><div class="actions"><a class="secondary" href="<?php echo e(route('purchases.show',$x)); ?>">View</a><a class="secondary" href="<?php echo e(route('purchases.edit',$x)); ?>">Edit</a><form method="post" action="<?php echo e(route('purchases.destroy',$x)); ?>" onsubmit="return confirm('Delete this purchase and reverse its stock? This cannot be undone.')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="danger" type="submit">Delete</button></form></div></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="empty">No purchases found.</td></tr><?php endif; ?>
</tbody></table></div>
<?php echo e($purchases->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/purchases/index.blade.php ENDPATH**/ ?>