<?php if($paginator->hasPages()): ?>
<nav class="app-pagination" role="navigation" aria-label="Pagination Navigation">
    <div class="app-pagination-summary">
        <?php if($paginator->firstItem()): ?>
            Showing <?php echo e($paginator->firstItem()); ?> to <?php echo e($paginator->lastItem()); ?> of <?php echo e($paginator->total()); ?> results
        <?php else: ?>
            Showing 0 results
        <?php endif; ?>
    </div>
    <div class="app-pagination-links">
        <?php if($paginator->onFirstPage()): ?>
            <span class="app-page disabled" aria-disabled="true" aria-label="Previous page">‹</span>
        <?php else: ?>
            <a class="app-page" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="Previous page">‹</a>
        <?php endif; ?>
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <span class="app-page dots"><?php echo e($element); ?></span>
            <?php endif; ?>
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="app-page active" aria-current="page"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a class="app-page" href="<?php echo e($url); ?>" aria-label="Go to page <?php echo e($page); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($paginator->hasMorePages()): ?>
            <a class="app-page" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="Next page">›</a>
        <?php else: ?>
            <span class="app-page disabled" aria-disabled="true" aria-label="Next page">›</span>
        <?php endif; ?>
    </div>
</nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>