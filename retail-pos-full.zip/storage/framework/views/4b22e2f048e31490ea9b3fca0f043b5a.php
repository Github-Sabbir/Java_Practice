<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <?php ($shopName = \App\Models\Setting::where('key', 'shop_name')->value('value') ?: 'Retail POS'); ?>
    <title><?php echo e($title ?? $shopName); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/pos.css')); ?>?v=18">
</head>
<body>
<aside class="sidebar">
    <div class="brand">
        <?php ($logoPath = \App\Models\Setting::where('key', 'logo_path')->value('value')); ?>
        <?php if($logoPath): ?>
            <img class="brand-logo" src="<?php echo e(route('media.file', ['path' => $logoPath])); ?>" alt="Logo">
        <?php else: ?>
            <span class="brand-mark">R</span>
        <?php endif; ?>
        <span><?php echo e(\App\Models\Setting::where('key', 'shop_name')->value('value') ?: 'Retail POS'); ?></span>
    </div>
    <div class="sidebar-label">Workspace</div>
    <nav>
        <a class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>"><span class="nav-icon">⌂</span>Dashboard</a>
        <?php if(auth()->user()->hasPermission('pos.access')): ?><a class="<?php echo e(request()->routeIs('pos') ? 'active' : ''); ?>" href="<?php echo e(route('pos')); ?>"><span class="nav-icon">▣</span>POS Terminal</a><?php endif; ?>
        <a class="<?php echo e(request()->routeIs('out-of-stock.*') ? 'active' : ''); ?>" href="<?php echo e(route('out-of-stock.index')); ?>"><span class="nav-icon">!</span>Out of Stock</a>
        <?php if(auth()->user()->hasPermission('products.view')): ?><a class="<?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>" href="<?php echo e(route('products.index')); ?>"><span class="nav-icon">◈</span>Products</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('barcodes.manage')): ?><a class="<?php echo e(request()->routeIs('barcodes.*') ? 'active' : ''); ?>" href="<?php echo e(route('barcodes.index')); ?>"><span class="nav-icon">⌁</span>Barcodes</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('purchases.manage')): ?><a class="<?php echo e(request()->routeIs('purchases.*') ? 'active' : ''); ?>" href="<?php echo e(route('purchases.index')); ?>"><span class="nav-icon">↗</span>Purchases</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('customers.view')): ?><a class="<?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>" href="<?php echo e(route('customers.index')); ?>"><span class="nav-icon">♙</span>Customers</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('suppliers.view')): ?><a class="<?php echo e(request()->routeIs('suppliers.*') ? 'active' : ''); ?>" href="<?php echo e(route('suppliers.index')); ?>"><span class="nav-icon">◇</span>Suppliers</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('expenses.view')): ?><a class="<?php echo e(request()->routeIs('expenses.*') ? 'active' : ''); ?>" href="<?php echo e(route('expenses.index')); ?>"><span class="nav-icon">−</span>Expenses</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('reports.view')): ?><a class="<?php echo e(request()->routeIs('reports') ? 'active' : ''); ?>" href="<?php echo e(route('reports')); ?>"><span class="nav-icon">◫</span>Reports</a><?php endif; ?>
        <?php if(in_array(auth()->user()->role, ['admin','manager'], true)): ?><a class="<?php echo e(request()->routeIs('sales.history') ? 'active' : ''); ?>" href="<?php echo e(route('sales.history')); ?>"><span class="nav-icon">▤</span>Sales History</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('returns.view')): ?><a class="<?php echo e(request()->routeIs('returns.*') ? 'active' : ''); ?>" href="<?php echo e(route('returns.index')); ?>"><span class="nav-icon">↩</span>Sales Returns</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('settings.manage')): ?><a class="<?php echo e(request()->routeIs('settings') ? 'active' : ''); ?>" href="<?php echo e(route('settings')); ?>"><span class="nav-icon">⚙</span>Settings</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('users.view')): ?><a class="<?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>"><span class="nav-icon">♙</span>Users</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('roles.manage')): ?><a class="<?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>"><span class="nav-icon">◉</span>Roles & Permissions</a><?php endif; ?>
    </nav>
    <form method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="nav-btn"><span class="nav-icon">⇥</span>Logout</button></form>
</aside>
<main>
<header class="topbar"><button class="icon-btn" onclick="document.body.classList.toggle('nav-open')">☰</button><div class="top-brand"><?php if(!empty($logoPath)): ?><img src="<?php echo e(route('media.file', ['path' => $logoPath])); ?>" alt="Logo"><?php endif; ?><strong><?php echo e($shopName); ?></strong></div><div class="top-actions"><button class="theme-btn" onclick="toggleTheme()" title="Toggle theme">◐</button><a class="top-user" href="<?php echo e(route('profile')); ?>"><span class="avatar"><?php if(auth()->user()->image): ?><img src="<?php echo e(route('media.file',['path'=>auth()->user()->image])); ?>" alt=""><?php else: ?><?php echo e(strtoupper(substr(auth()->user()->name ?? 'U',0,1))); ?><?php endif; ?></span><span><?php echo e(auth()->user()->name ?? 'User'); ?></span></a></div></header>
<?php if(session('success')): ?><div class="toast success"><?php echo e(session('success')); ?></div><?php endif; ?>
<?php if($errors->any()): ?><div class="toast error"><?php echo e($errors->first()); ?></div><?php endif; ?>
<div class="page"><?php echo $__env->yieldContent('content'); ?></div>
</main>
<script src="<?php echo e(asset('js/pos.js')); ?>?v=18"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/layouts/app.blade.php ENDPATH**/ ?>