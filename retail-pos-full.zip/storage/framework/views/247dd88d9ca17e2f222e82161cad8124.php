<?php $__env->startSection('content'); ?>
<div class="page-head"><div><div class="eyebrow">INVENTORY ALERT</div><h1>Out of Stock</h1><p class="muted">Products with zero or negative stock. Everyone can view this list.</p></div><span class="cart-badge"><?php echo e($products->total()); ?> products</span></div>
<div class="glass table-wrap"><table><thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Stock</th><th>Minimum</th><th>Status</th><?php if(auth()->user()->role==='admin'): ?><th>Admin Action</th><?php endif; ?></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr><td><strong><?php echo e($p->name); ?></strong></td><td><?php echo e($p->sku); ?></td><td><?php echo e($p->category?->name ?? '—'); ?></td><td class="low"><strong>0</strong></td><td><?php echo e($p->minimum_stock); ?></td><td><span class="status off">Out of Stock</span></td><?php if(auth()->user()->role==='admin'): ?><td><form method="post" action="<?php echo e(route('out-of-stock.archive',$p)); ?>" onsubmit="return confirm('Archive this out-of-stock product?')"><?php echo csrf_field(); ?><button class="danger" type="submit">Delete / Archive</button></form></td><?php endif; ?></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="<?php echo e(auth()->user()->role==='admin' ? 7 : 6); ?>" class="empty">No out-of-stock products.</td></tr><?php endif; ?>
</tbody></table></div>
<?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/products/out-of-stock.blade.php ENDPATH**/ ?>