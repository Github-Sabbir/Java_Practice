<?php $__env->startSection('content'); ?>
<div class="page-head"><div><div class="eyebrow">PRODUCT IDENTIFICATION</div><h1>Barcode Manager</h1><p class="muted">Attach multiple unique barcodes to a product, choose one primary barcode, generate internal codes and print labels.</p></div></div>

<div class="barcode-tools">
<section class="glass form-card"><div class="section-head"><div><h2>Add Barcode</h2><p class="muted">USB scanner or manual entry.</p></div></div>
<form method="post" action="<?php echo e(route('barcodes.store')); ?>" class="form-grid single-form"><?php echo csrf_field(); ?>
<label>Product<select name="product_id" required><option value="">Select product</option><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?> — <?php echo e($p->sku); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
<label>Barcode<input name="barcode" autofocus placeholder="Scan or type barcode" required></label>
<label class="check"><input type="checkbox" name="is_primary" value="1"> Set as primary</label>
<button class="primary" type="submit">Save Barcode</button>
</form></section>
<section class="glass form-card"><div class="section-head"><div><h2>Bulk Generate</h2><p class="muted">Creates internal Code-128-compatible numeric values for your own labels.</p></div></div>
<form method="post" action="<?php echo e(route('barcodes.bulk')); ?>" class="form-grid single-form"><?php echo csrf_field(); ?>
<label>Product<select name="product_id" required><option value="">Select product</option><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?> — <?php echo e($p->sku); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
<label>Number of barcodes<input type="number" name="count" min="1" max="100" value="10" required></label>
<button class="primary" type="submit">Generate</button>
</form></section>
</div>

<form class="glass toolbar" method="get"><input name="q" value="<?php echo e($search); ?>" placeholder="Search product, SKU or barcode..."><button class="primary" type="submit">Search</button><?php if($search): ?><a class="secondary" href="<?php echo e(route('barcodes.index')); ?>">Clear</a><?php endif; ?></form>

<div class="glass table-wrap"><table><thead><tr><th>Product</th><th>SKU</th><th>Barcode</th><th>Primary</th><th>Actions</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <?php ($product = $b->product); ?> <tr><td><b><?php echo e($product?->name ?? 'Unknown product'); ?></b><?php if($product?->trashed()): ?> <span class="status off">Archived</span><?php endif; ?></td><td><?php echo e($product?->sku ?? '—'); ?></td><td><code><?php echo e($b->barcode); ?></code></td><td><?php if($b->is_primary): ?><span class="status ok">Primary</span><?php else: ?><span class="status">Secondary</span><?php endif; ?></td><td><div class="actions"><?php if (! ($b->is_primary)): ?><form method="post" action="<?php echo e(route('barcodes.primary',$b)); ?>"><?php echo csrf_field(); ?><button class="secondary" type="submit">Make Primary</button></form><?php endif; ?><form method="post" action="<?php echo e(route('barcodes.destroy',$b)); ?>"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="danger" type="submit" onclick="return confirm('Delete this barcode?')">Delete</button></form><button class="secondary" type="button" onclick="printBarcode('<?php echo e(addslashes($b->barcode)); ?>','<?php echo e(addslashes($product?->name ?? 'Unknown product')); ?>')">Print</button></div></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="empty">No barcodes found.</td></tr><?php endif; ?>
</tbody></table></div>
<?php echo e($barcodes->links()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
function printBarcode(code,name){const w=window.open('','barcode','width=420,height=420');if(!w)return;w.document.write('<!doctype html><html><head><title>Barcode '+code+'</title><style>@page{size:58mm 30mm;margin:0}body{font-family:Arial;text-align:center;padding:5mm}.name{font-size:12px;font-weight:bold}.code{font-family:monospace;font-size:18px;letter-spacing:2px;margin-top:8px}</style></head><body><div class="name">'+name.replace(/</g,'&lt;')+'</div><div class="code">'+code+'</div><script>setTimeout(()=>window.print(),200)<\\/script></body></html>');w.document.close();}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/products/barcodes.blade.php ENDPATH**/ ?>