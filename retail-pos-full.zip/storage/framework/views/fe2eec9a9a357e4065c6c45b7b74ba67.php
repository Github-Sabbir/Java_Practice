<?php $__env->startSection('content'); ?>
<div class="pos-shell">
<section class="glass pos-products">
    <div class="pos-head"><div><div class="eyebrow">FAST CHECKOUT</div><h1>POS Terminal</h1><p>Scan a barcode, type a product name or click a product.</p></div><div class="pos-search-wrap"><input id="scan" class="scan" autocomplete="off" autofocus placeholder="⌕  Scan barcode / search product..." oninput="searchPOSLive()" onkeydown="if(event.key==='Enter'){lookupPOS(true)}"><div id="pos-suggestions" class="pos-suggestions"></div></div></div>
    <div id="product-grid" class="product-grid"></div>
</section>
<section class="glass cart-panel"><div class="cart-head"><div><h2 style="margin:0">Current Sale</h2><small class="muted">Live cart</small></div><span class="cart-badge" id="cart-count">0 items</span></div><div id="cart"></div><div class="summary">
    <div>Subtotal <b id="subtotal">৳0.00</b></div>
    <div>Discount <input id="discount" type="number" step=".01" value="0" oninput="renderCart()"></div>
    <div><span>Tax <small class="muted">(from product settings)</small></span><b id="tax-total">৳0.00</b></div>
    <div class="grand">Total <b id="grand">৳0.00</b></div>
    <div class="pos-customer-box">
        <label>Customer phone <span class="optional">optional</span><input id="customer-phone" type="tel" inputmode="tel" autocomplete="off" placeholder="01XXXXXXXXX" oninput="searchCustomerByPhone()"><div id="customer-suggestions" class="customer-suggestions"></div></label>
        <label>Customer name <span class="optional">optional</span><input id="customer-name" type="text" placeholder="Walk-in / customer name"></label>
        <div class="customer-actions"><select id="customer"><option value="">Walk-in Customer</option><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" data-phone="<?php echo e($c->phone); ?>"><?php echo e($c->name); ?> — <?php echo e($c->phone ?: 'No phone'); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><button type="button" class="secondary" onclick="quickAddCustomer()">＋ Add Customer</button></div>
        <small id="customer-status" class="muted">Phone is optional. Start typing to find an existing customer.</small>
    </div>
    <label>Payment<select id="payment"><option value="cash">Cash</option><option value="card">Card</option><option value="mobile">Mobile banking</option><option value="other">Other</option></select></label><label>Paid<input id="paid" type="number" step=".01" value="0"></label><button class="primary wide" onclick="checkoutPOS()">Pay & Complete Sale</button><button class="secondary wide" onclick="clearCart()">Clear Cart</button>
</div></section></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?><script>
window.POS={lookup:"<?php echo e(url('/pos/product')); ?>",customerLookup:"<?php echo e(url('/pos/customer')); ?>",customerQuick:"<?php echo e(route('pos.customer.quick')); ?>",checkout:"<?php echo e(route('pos.checkout')); ?>",receiptBase:"<?php echo e(url('/sales')); ?>",csrf:"<?php echo e(csrf_token()); ?>",products:<?php echo json_encode($products, 15, 512) ?>};
window.addEventListener('DOMContentLoaded',()=>{renderProducts(window.POS.products||[]);renderCart();});
</script><?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/pos/index.blade.php ENDPATH**/ ?>