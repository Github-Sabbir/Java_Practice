<?php $__env->startSection('content'); ?>
<div class="page-head">
    <div><div class="eyebrow">STORE OVERVIEW</div><h1>Good day, <?php echo e(auth()->user()->name); ?> 👋</h1><p class="muted">Activity from <?php echo e($from->format('d M Y')); ?> to <?php echo e($to->format('d M Y')); ?>.</p></div>
    <?php if(auth()->user()->role === 'admin' || auth()->user()->role === 'manager'): ?><a class="secondary" href="<?php echo e(route('reports')); ?>">View Reports</a><?php endif; ?>
    <a class="primary" href="<?php echo e(route('pos')); ?>">＋ Open POS</a>
</div>
<?php if(auth()->user()->role === 'admin' || auth()->user()->role === 'manager'): ?>
<form class="glass dashboard-filter" method="get">
    <div><strong>Activity period</strong><small class="muted"><?php echo e(auth()->user()->role === 'manager' ? 'Manager: maximum 7 days' : 'Admin: choose any period'); ?></small></div>
    <label>From <input type="date" name="from" value="<?php echo e($from->toDateString()); ?>"></label>
    <span class="date-arrow">→</span>
    <label>To <input type="date" name="to" value="<?php echo e($to->toDateString()); ?>"></label>
    <?php if(auth()->user()->role === 'manager'): ?><a class="secondary" href="<?php echo e(route('dashboard', ['from'=>now()->subDays(6)->toDateString(),'to'=>now()->toDateString()])); ?>">Last 7 Days</a><?php endif; ?>
    <button class="primary" type="submit">Apply</button>
    <a class="secondary" href="<?php echo e(route('dashboard')); ?>">Today</a>
</form>
<?php endif; ?>
<div class="stats">
    <div class="stat"><div class="stat-top"><span>Sales</span><span class="stat-icon">↗</span></div><b>৳<?php echo e(number_format($sales,2)); ?></b><small><?php echo e($transactions); ?> completed transactions</small></div>
    <div class="stat"><div class="stat-top"><span>Returns</span><span class="stat-icon">↩</span></div><b>৳<?php echo e(number_format($returns,2)); ?></b><small>Refund value in period</small></div>
    <div class="stat"><div class="stat-top"><span>Low Stock</span><span class="stat-icon">!</span></div><b><?php echo e($lowStock); ?></b><small>Products at/below minimum</small></div>
    <?php if($canSeeFinance): ?><div class="stat finance-stat"><div class="stat-top"><span>Net Profit</span><span class="stat-icon">✓</span></div><b>৳<?php echo e(number_format($netProfit,2)); ?></b><small>Revenue − COGS − expenses</small></div><?php endif; ?>
</div>
<?php if($canSeeFinance): ?>
<div class="stats finance-stats dashboard-finance-same">
    <div class="stat"><div class="stat-top"><span>Purchases</span><span class="stat-icon">↗</span></div><b>৳<?php echo e(number_format($purchases,2)); ?></b><small>Stock investment</small></div>
    <div class="stat"><div class="stat-top"><span>COGS</span><span class="stat-icon">◈</span></div><b>৳<?php echo e(number_format($cogs,2)); ?></b><small>Cost of sold items</small></div>
    <div class="stat"><div class="stat-top"><span>Expenses</span><span class="stat-icon">−</span></div><b>৳<?php echo e(number_format($expenses,2)); ?></b><small>Operating expenses</small></div>
    <div class="stat"><div class="stat-top"><span>Gross Profit</span><span class="stat-icon">✓</span></div><b>৳<?php echo e(number_format($grossProfit,2)); ?></b><small>Revenue before expenses</small></div>
</div>
<?php endif; ?>
<div class="dashboard-grid">
    <section class="glass card chart-card">
        <div class="section-head"><div><h2>Sales activity</h2><p class="muted"><?php echo e($days === 1 ? '24-hour activity · 12 AM to 12 AM' : 'Daily activity for the selected period'); ?></p></div><span class="cart-badge"><?php echo e($days); ?> day<?php echo e($days === 1 ? '' : 's'); ?></span></div>
        <div class="chart-bars chart-bars-dashboard">
            <?php ($maxActivity=max(1,max(array_column($activity,'sales')))); ?>
            <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="chart-column"><div class="chart-bar" style="height:<?php echo e(max(4, ($point['sales'] / $maxActivity) * 100)); ?>%" title="<?php echo e($point['label']); ?> · ৳<?php echo e(number_format($point['sales'],2)); ?>"></div><small><?php echo e($point['label']); ?></small></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <section class="glass card"><h2>Quick actions</h2><p class="muted">Jump directly into common tasks.</p><div class="quick">
        <a href="<?php echo e(route('pos')); ?>">Open POS</a>
        <?php if(auth()->user()->hasPermission('products.manage')): ?><a href="<?php echo e(route('products.create')); ?>">＋ Product</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('customers.create')): ?><a href="<?php echo e(route('customers.create')); ?>">＋ Customer</a><?php endif; ?>
        <?php if(auth()->user()->hasPermission('expenses.create')): ?><a href="<?php echo e(route('expenses.create')); ?>">＋ Expense</a><?php endif; ?>
    </div><div class="mini-list" style="margin-top:18px">
        <?php if($canSeeFinance): ?><div class="mini-row"><span>Reports</span><a class="secondary" href="<?php echo e(route('reports')); ?>">View →</a></div><?php endif; ?>
        <?php if(auth()->user()->hasPermission('returns.view')): ?><div class="mini-row"><span>Sales Returns</span><a class="secondary" href="<?php echo e(route('returns.index')); ?>">Open →</a></div><?php endif; ?>
    </div></section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\retail-pos-full\resources\views/dashboard/index.blade.php ENDPATH**/ ?>