<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\BarcodeController;
use App\Http\Controllers\PosController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ReturnController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\UserManagementController;
use App\Http\Controllers\MediaController;
use App\Http\Controllers\BackupController;
use App\Http\Controllers\SalesHistoryController;
use App\Http\Controllers\OutOfStockController;
use App\Http\Controllers\ProfileController;
Route::get('/', fn() => redirect()->route('dashboard'));
Route::get('/login', [AuthController::class, 'show'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.store');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/media/{path}', [MediaController::class, 'file'])->where('path', '.*')->name('media.file');
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/out-of-stock', [OutOfStockController::class, 'index'])->name('out-of-stock.index');
    Route::middleware('permission:products.archive')->post('/out-of-stock/{product}/archive', [OutOfStockController::class, 'archive'])->name('out-of-stock.archive');
    Route::get('/profile', [ProfileController::class, 'show'])->name('profile');
    Route::middleware('permission:pos.access')->group(function () {
        Route::get('/pos', [PosController::class, 'index'])->name('pos');
        Route::post('/pos/checkout', [PosController::class, 'checkout'])->name('pos.checkout');
    });
    Route::middleware('permission:pos.access')->get('/pos/product/{query}', [PosController::class, 'lookup'])->name('pos.lookup');
    Route::middleware('permission:pos.access')->get('/pos/customer/{phone}', [PosController::class, 'customerLookup'])->name('pos.customer.lookup');
    Route::middleware('permission:customers.create')->post('/pos/customer', [PosController::class, 'quickCustomer'])->name('pos.customer.quick');
    Route::middleware('permission:products.view')->get('/products', [ProductController::class, 'index'])->name('products.index');
    Route::middleware('permission:products.manage')->group(function () {
        Route::get('/products/create', [ProductController::class, 'create'])->name('products.create');
        Route::post('/products', [ProductController::class, 'store'])->name('products.store');
        Route::get('/products/{product}/edit', [ProductController::class, 'edit'])->name('products.edit');
        Route::put('/products/{product}', [ProductController::class, 'update'])->name('products.update');
        Route::post('/products/{product}/image', [ProductController::class, 'image'])->name('products.image');
        Route::delete('/products/{product}/image', [ProductController::class, 'removeImage'])->name('products.image.remove');
    });
    Route::middleware('permission:products.archive')->delete('/products/{product}', [ProductController::class, 'destroy'])->name('products.destroy');
    Route::middleware('permission:products.restore')->post('/products/{id}/restore', [ProductController::class, 'restore'])->name('products.restore');
    Route::middleware('permission:barcodes.manage')->group(function () {
        Route::get('/barcodes', [BarcodeController::class, 'index'])->name('barcodes.index');
        Route::post('/barcodes', [BarcodeController::class, 'store'])->name('barcodes.store');
        Route::post('/barcodes/{barcode}/primary', [BarcodeController::class, 'setPrimary'])->name('barcodes.primary');
        Route::post('/barcodes/bulk-generate', [BarcodeController::class, 'bulkGenerate'])->name('barcodes.bulk');
        Route::delete('/barcodes/{barcode}', [BarcodeController::class, 'destroy'])->name('barcodes.destroy');
    });
    Route::middleware('permission:purchases.manage')->resource('purchases', PurchaseController::class)->only(['index', 'create', 'store', 'show', 'edit', 'update', 'destroy']);
    Route::middleware('permission:customers.view')->group(function () {
        Route::get('/customers', [CustomerController::class, 'index'])->name('customers.index');
        Route::get('/customers/{customer}/edit', [CustomerController::class, 'edit'])->name('customers.edit');
    });
    Route::middleware('permission:customers.create')->post('/customers', [CustomerController::class, 'store'])->name('customers.store');
    Route::middleware('permission:customers.create')->get('/customers/create', [CustomerController::class, 'create'])->name('customers.create');
    Route::middleware('permission:customers.edit')->put('/customers/{customer}', [CustomerController::class, 'update'])->name('customers.update');
    Route::middleware('permission:customers.delete')->delete('/customers/{customer}', [CustomerController::class, 'destroy'])->name('customers.destroy');
    Route::middleware('permission:customers.payment')->post('/customers/{customer}/payment', [CustomerController::class, 'payment'])->name('customers.payment');
    Route::middleware('permission:suppliers.view')->group(function () {
        Route::get('/suppliers', [SupplierController::class, 'index'])->name('suppliers.index');
        Route::get('/suppliers/{supplier}/edit', [SupplierController::class, 'edit'])->name('suppliers.edit');
    });
    Route::middleware('permission:suppliers.create')->get('/suppliers/create', [SupplierController::class, 'create'])->name('suppliers.create');
    Route::middleware('permission:suppliers.create')->post('/suppliers', [SupplierController::class, 'store'])->name('suppliers.store');
    Route::middleware('permission:suppliers.edit')->put('/suppliers/{supplier}', [SupplierController::class, 'update'])->name('suppliers.update');
    Route::middleware('permission:suppliers.delete')->delete('/suppliers/{supplier}', [SupplierController::class, 'destroy'])->name('suppliers.destroy');
    Route::middleware('permission:suppliers.payment')->post('/suppliers/{supplier}/payment', [SupplierController::class, 'payment'])->name('suppliers.payment');
    Route::middleware('permission:expenses.view')->group(function () {
        Route::get('/expenses', [ExpenseController::class, 'index'])->name('expenses.index');
        Route::get('/expenses/{expense}/edit', [ExpenseController::class, 'edit'])->name('expenses.edit');
    });
    Route::middleware('permission:expenses.create')->group(function () {
        Route::get('/expenses/create', [ExpenseController::class, 'create'])->name('expenses.create');
        Route::post('/expenses', [ExpenseController::class, 'store'])->name('expenses.store');
    });
    Route::middleware('permission:expenses.edit')->put('/expenses/{expense}', [ExpenseController::class, 'update'])->name('expenses.update');
    Route::middleware('permission:expenses.delete')->delete('/expenses/{expense}', [ExpenseController::class, 'destroy'])->name('expenses.destroy');
    Route::middleware('permission:reports.view')->get('/reports', [ReportController::class, 'index'])->name('reports');
    Route::middleware('permission:returns.view')->get('/returns', [ReturnController::class, 'index'])->name('returns.index');
    Route::middleware('permission:returns.view')->get('/returns/sale/{invoice}', [ReturnController::class, 'lookup'])->name('returns.lookup');
    Route::middleware('permission:returns.create')->post('/returns', [ReturnController::class, 'store'])->name('returns.store');
    Route::middleware('permission:receipts.print')->get('/sales/{sale}/receipt', [PosController::class, 'receipt'])->name('sales.receipt');
    Route::get('/sales-history', [SalesHistoryController::class, 'index'])->name('sales.history');
    Route::middleware('permission:settings.manage')->group(function () {
        Route::get('/settings', [SettingsController::class, 'index'])->name('settings');
        Route::post('/settings', [SettingsController::class, 'update'])->name('settings.update');
        Route::post('/settings/logo/remove', [SettingsController::class, 'removeLogo'])->name('settings.logo.remove');
        Route::get('/settings/backup', [BackupController::class, 'download'])->middleware('permission:backup.manage')->name('settings.backup.download');
        Route::post('/settings/backup/restore', [BackupController::class, 'restore'])->middleware('permission:backup.manage')->name('settings.backup.restore');
    });
    Route::middleware('permission:users.view')->get('/users', [UserManagementController::class, 'index'])->name('users.index');
    Route::middleware('permission:users.create')->group(function () {
        Route::get('/users/create', [UserManagementController::class, 'create'])->name('users.create');
        Route::post('/users', [UserManagementController::class, 'store'])->name('users.store');
    });
    Route::middleware('permission:users.edit')->group(function () {
        Route::get('/users/{user}/edit', [UserManagementController::class, 'edit'])->name('users.edit');
        Route::put('/users/{user}', [UserManagementController::class, 'update'])->name('users.update');
    });
    Route::middleware('permission:users.delete')->delete('/users/{user}', [UserManagementController::class, 'destroy'])->name('users.destroy');
    Route::middleware('permission:users.view')->get('/users/{user}', [ProfileController::class, 'adminShow'])->name('users.show');
    Route::middleware('permission:roles.manage')->group(function () {
        Route::get('/roles', [UserManagementController::class, 'roles'])->name('roles.index');
        Route::post('/roles', [UserManagementController::class, 'storeRole'])->name('roles.store');
        Route::put('/roles/{role}', [UserManagementController::class, 'updateRole'])->name('roles.update');
        Route::delete('/roles/{role}', [UserManagementController::class, 'destroyRole'])->name('roles.destroy');
    });
});
